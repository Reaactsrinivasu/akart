
export const BASE_URL = "http://64.227.181.53:3000/"; // current working url
export const STATUS_CODE = {
  INTERNAL_SERVER_ERROR: 500,
  SUCCESS: 200,
};
