import React from 'react'

const Avatar = () => {
    return (
        <div>Avatar</div>
    );
};

export default Avatar;