import React from 'react'

const Theme = () => {
    return (
        <div>Theme</div>
    );
};

export default Theme;