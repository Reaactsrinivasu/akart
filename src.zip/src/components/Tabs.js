
import React from 'react'

const Tabs = () => {
    return (
        <div>Tabs</div>
    );
};

export default Tabs;