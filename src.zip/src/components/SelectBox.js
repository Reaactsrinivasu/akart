import React from 'react'

const SelectBox = () => {
    return (
        <div>SelectBox</div>
    );
};

export default SelectBox;