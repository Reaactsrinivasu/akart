import React from "react";
import { useNavigate } from "react-router-dom";
import {
  Typography,
  Grid,
  Box,
  Divider,
  Button,
  List,
  ListItemIcon,
  ListItemButton,
  InboxIcon,
  ListItem,
  ListItemText,
} from "@mui/material";
import FiberManualRecordTwoToneIcon from "@mui/icons-material/FiberManualRecordTwoTone";
import ProductAvailability from "../Products/ProductAvailability";
import ReusableListWithDotIcon from "../../../components/ListWithDotIcon";
const InnerProductDetails = () => {
  const navigate = useNavigate();
  const productImages = [
    {
      image:
        "https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/z/y/i/-original-imagy5wg4pqpymyh.jpeg?q=70&crop=false",
    },
    {
      image:
        "https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/y/r/4/-original-imagy5wgw3sthjzg.jpeg?q=70&crop=false",
    },
    {
      image:
        "https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/4/h/w/-original-imagy5wgyrdw8hsz.jpeg?q=70&crop=false",
    },
    {
      image:
        "https://rukminim2.flixcart.com/image/128/128/xif0q/mobile/r/h/m/-original-imagy5wgt58ycehf.jpeg?q=70&crop=false",
    },
  ];
  const productDetails = [
    {
      id: "1",
      // image: "assets/imgs/phone.jpg",
      image: "assets/imgs/phone1.png",
      title1:
        "SAMSUNG 80 cm (32 Inch) HD Ready LED Smart Tizen TV 2022 Edition with Bezel-free Design  (UA32T4380AKXXL)",
      title2: "",
      title3: "",
      actualPrice: "",
      discount: "",
      discountPrice: "",
      rating: "4.2★",
      ratedes: "1,92,450 Ratings & 10,456 Reviews",
      descList: [
        "Supported Apps: Netflix|Prime Video|",
        "Disney+Hotstar|Youtube",
        "Operating System: Tizen",
        "Resolution: HD Ready 1366 x 768 Pixels",
        "Sound Output: 20 W",
        "Refresh Rate: 50 Hz",
      ],
      list: [
        { item: "Available offers" },
        {
          item: "Bank Offer 10% off on BOBCARD EMI Transactions, up to ₹1,500 on orders of ₹10,000 and above",
        },
        // "T&C",
        {
          item: "Bank Offer 10% off on Citi-branded Credit Card EMI Transactions, up to ₹1,500 on orders of ₹7,500 and above",
        },
        // "T&C",
        {
          item: "Bank Offer Flat ₹750 off on OneCard Credit Card EMI Transactions on orders of ₹12,500 and above",
        },
        // "T&C",
        {
          item: "Partner OfferFlat 1% Instant discount up to ₹ 1,000 on purchase of Flipkart Digital Gift Cards",
        },
        {
          item: "Partner OfferSign-up for Flipkart Pay Later & get free Times Prime Benefits worth ₹20,000",
        },
        {
          item: "Partner OfferMake a purchase and enjoy a surprise cashback/ coupon that you can redeem later!",
        },
        {
          item: "No cost EMI ₹7,333/month. Standard EMI also available",
        },
        {
          item: "Extra 10% Off On Combo Mobile & Casecover- Oct'24",
        },
        {
          item: "Extra 10% off on Combo with Vivo - Oct'24",
        },
        {
          item: "Extra ₹200 off on Noise Pure Pods",
        },
      ],
    },
    // {
    //   id: "2",
    //   image: "assets/imgs/laptop1.jpg",
    //   title1:
    //     "HP 80 cm (32 Inch) HD Ready LED Smart Tizen TV 2022 Edition with Bezel-free Design  (UA32T4380AKXXL)",
    //   title2: "",
    //   title3: "",
    //   actualPrice: "",
    //   discount: "",
    //   discountPrice: "",
    //   rating: "4.6★",
    //   ratedes: "1,92,450 Ratings & 10,456 Reviews",
    //   descList: [
    //     "Supported Apps: Netflix|Prime Video|",
    //     "Disney+Hotstar|Youtube",
    //     "Operating System: Tizen",
    //     "Resolution: HD Ready 1366 x 768 Pixels",
    //     "Sound Output: 20 W",
    //     "Refresh Rate: 50 Hz",
    //   ],
    // },
    // {
    //   id: "3",
    //   image: "assets/imgs/phone1.png",
    //   title1:
    //     "SAMSUNG 80 cm (32 Inch) HD Ready LED Smart Tizen TV 2022 Edition with Bezel-free Design  (UA32T4380AKXXL)",
    //   title2: "",
    //   title3: "",
    //   actualPrice: "",
    //   discount: "",
    //   discountPrice: "",
    //   rating: "3.5★",
    //   ratedes: "1,92,450 Ratings & 10,456 Reviews",
    //   descList: [
    //     "Supported Apps: Netflix|Prime Video|",
    //     "Disney+Hotstar|Youtube",
    //     "Operating System: Tizen",
    //     "Resolution: HD Ready 1366 x 768 Pixels",
    //     "Sound Output: 20 W",
    //     "Refresh Rate: 50 Hz",
    //   ],
    // },
    // {
    //   id: "4",
    //   image: "assets/imgs/laptop1.jpg",
    //   title1:
    //     "HP 80 cm (32 Inch) HD Ready LED Smart Tizen TV 2022 Edition with Bezel-free Design  (UA32T4380AKXXL)",
    //   title2: "",
    //   title3: "",
    //   actualPrice: "",
    //   discount: "",
    //   discountPrice: "",
    //   rating: "3.8★",
    //   ratedes: "1,92,450 Ratings & 10,456 Reviews",
    //   descList: [
    //     "Supported Apps: Netflix|Prime Video|",
    //     "Disney+Hotstar|Youtube",
    //     "Operating System: Tizen",
    //     "Resolution: HD Ready 1366 x 768 Pixels",
    //     "Sound Output: 20 W",
    //     "Refresh Rate: 50 Hz",
    //   ],
    // },
    // {
    //   id: "5",
    //   image: "assets/imgs/phone1.png",
    //   title1:
    //     "SAMSUNG 80 cm (32 Inch) HD Ready LED Smart Tizen TV 2022 Edition with Bezel-free Design  (UA32T4380AKXXL)",
    //   title2: "",
    //   title3: "",
    //   actualPrice: "",
    //   discount: "",
    //   discountPrice: "",
    //   rating: "4.5★",
    //   ratedes: "1,92,450 Ratings & 10,456 Reviews",
    //   descList: [
    //     "Supported Apps: Netflix|Prime Video|",
    //     "Disney+Hotstar|Youtube",
    //     "Operating System: Tizen",
    //     "Resolution: HD Ready 1366 x 768 Pixels",
    //     "Sound Output: 20 W",
    //     "Refresh Rate: 50 Hz",
    //   ],
    // },
    // {
    //   id: "6",
    //   image: "assets/imgs/laptop1.jpg",
    //   title1:
    //     "HP 80 cm (32 Inch) HD Ready LED Smart Tizen TV 2022 Edition with Bezel-free Design  (UA32T4380AKXXL)",
    //   title2: "",
    //   title3: "",
    //   actualPrice: "",
    //   discount: "",
    //   discountPrice: "",
    //   rating: "4.2★",
    //   ratedes: "1,92,450 Ratings & 10,456 Reviews",
    //   descList: [
    //     "Supported Apps: Netflix|Prime Video|",
    //     "Disney+Hotstar|Youtube",
    //     "Operating System: Tizen",
    //     "Resolution: HD Ready 1366 x 768 Pixels",
    //     "Sound Output: 20 W",
    //     "Refresh Rate: 50 Hz",
    //   ],
    // },
  ];

  const list = [
    {
      id: 1,
      item: "The weight of the phone is 207 g, and the weight of thescreen protector may add an additional 3g. The size andweight of the mobile phone may vary according to configuration, manufacturing process and measurement The weight of the phone is 207 g, and the weight of the screen protector may add an additional 3g. The size and weight of the mobile phone may vary according to configuration, manufacturing process and measurement method. 3. Due to the mobile phone system file occupying space (including Android system and pre-installed apps), the available memory capacity is less than this value. Storage capacity will vary based on software version and may vary from device to device. 4. Photo pixels of different camera modes may vary, please refer to the actual situation. Video pixels of different shooting modes may also vary, please refer to the actual situation. 5. The battery of OnePlus 12R adopts a series dual-cell design, with a typical capacity of 2750mAh (7.82V), equivalent to 5500mAh (3.91V); typical energy: 21.51Wh. The rated capacity is 2680mAh (7.82V), equivalent to 5360mAh (3.91V); rated energy: 20.96Wh. The battery is non-removable. 6. Product pictures and content on the page are for illustrative purposes only. The actual results (including but not limited to appearance, color, size) and the screen display content (including but not limited to background, UI, and picture) may vary; 7. At least three generations of android OS upgrades and four years of security updates from the launch date. 8. Numbers are theoretical, obtained under a controlled test environment (see each specific description) and provided by the supplier or the OnePlus laboratory. Actual performance may vary due to individual product differences, software versions, use conditions and environmental factors. Please refer to the actual experience. 9. Due to the real-time changes in product batches and supply factors, in order to provide accurate information on product information, specifications, and product characteristics, OnePlus may adjust and revise the text descriptions, picture effects, and other content on the above pages in real time to match the reality of the product performance, specifications, index, parts and other information; in the event that page modifications and adjustments are necessary, no special notice will be given. 10. The highest reported SAR value: Head SAR: 1.187 W/Kg; Body SAR: 0.824 W/Kg",
    },
  ];
  return (
    <>
      <Box sx={{ p: 0.5 }}>
        <Box
          sx={{
            width: "100%",
            height: "100%",
            backgroundColor: "#FFFFFF",
            p: 2,
          }}
        >
          <Grid container p={0} spacing={1}>
            {/* pink color component */}
            <Grid item xs={12} sm={6} md={5}>
              <Grid
                container
                p={0}
                spacing={0}
                sx={{ position: "sticky", top: "70px", marginTop: "1px" }}
              >
                <Grid item xs={12} sm={12} md={2}>
                  <Box
                    sx={{
                      backgroundColor: "#FFFFFF",
                      border: "1px solid",
                      borderColor: "divider",
                    }}
                  >
                    <Grid container spacing={0}>
                      {productImages?.map((item, index) => (
                        <Grid
                          item
                          xs={12}
                          sm={12}
                          md={12}
                          key={index}
                          sx={{
                            border: "1px solid",
                            borderColor: "divider",
                            justifyContent: "center",
                            display: "flex",
                          }}
                        >
                          <img
                            src={item.image}
                            alt="1"
                            sx={{ width: "80px", height: "80px" }}
                          />
                        </Grid>
                      ))}
                    </Grid>
                  </Box>
                </Grid>
                <Grid item xs={12} sm={12} md={10}>
                  <Box
                    sx={{
                      width: "100%",
                      height: "100%",
                      backgroundColor: "#FFFFFF",
                      border: "1px solid",
                      borderLeft: 0,
                      borderColor: "divider",
                      // borderRadius: "8px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      // justifyContent:'center'
                      padding: 1,
                    }}
                  >
                    <Box
                      sx={{
                        width: "100%",
                        height: "100%",
                        backgroundColor: "#FFFFFF",
                        // border: "1px solid",
                        // borderColor: "divider",
                        // borderRadius: "8px",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        // justifyContent:'center'
                      }}
                    >
                      <img
                        src="assets/imgs/phone.jpg"
                        alt="1"
                        style={{ width: "100%", height: "100%" }}
                      />
                    </Box>
                  </Box>
                </Grid>
              </Grid>
            </Grid>
            {/*cyan color component */}
            <Grid item xs={12} sm={6} md={7}>
              <Box
                sx={{
                  width: "100%",
                  height: "100%",
                  bgcolor: "#FFFFFF",
                  // border: "1px solid",
                  // borderColor: "divider",
                  borderRadius: "8px",
                }}
              >
                <Typography
                  p={1}
                  sx={{
                    color: "text.secondary",
                  }}
                >
                  Home {">"} Mobiles & Accessories {">"} Mobiles {">"} OnePlus
                </Typography>
                <Typography
                  variant="h4"
                  fontWeight="bold"
                  p={1}
                  mt={1}
                  mb={1}
                  sx={{
                    color: "text.secondary",
                  }}
                >
                  Showing 1 – 24 of 749 results for "new launch mobiles"
                </Typography>
                <Divider variant="fullWidth" />
                {productDetails?.map((item, index) => (
                  <Grid
                    p={1}
                    container
                    spacing={0}
                    display="flex"
                    flexDirection="column"
                    justifyContent="center"
                    // alignItems="center"
                  >
                    <Grid item xs={12} sm={12} md={12}>
                      <Grid container spacing={3}>
                        <Grid item xs={12} sm={8} md={8}>
                          <Typography variant="h5" fontWeight="bold">
                            {item.title1}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={8} md={4}>
                          <Box
                            sx={{
                              display: "flex",
                              flexDirection: "column",
                            }}
                          >
                            <Typography variant="h4" sx={{ color: "#212121" }}>
                              ₹2500
                            </Typography>
                            <Box
                              sx={{
                                display: "flex",
                                justifyContent: "flex-start",
                              }}
                            >
                              <Typography
                                variant="h4"
                                fontWeight="bold"
                                sx={{
                                  color: "#878787",
                                  textDecorationLine: "line-through",
                                }}
                              >
                                ₹2500
                              </Typography>
                              <Typography
                                variant="h4"
                                sx={{ ml: 3, color: "#308150" }}
                              >
                                20% OFF
                              </Typography>
                            </Box>
                          </Box>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12}>
                      <Box
                        sx={{
                          display: "flex",
                          flexDirection: "row",
                          justifyContent: "flex-start",
                          alignItems: "center",
                          gap: 2,
                        }}
                      >
                        <Button
                          variant="contained"
                          sx={{
                            backgroundColor: "#3B7E42",
                            borderRadius: "12px",
                            fontSize: "15px",
                            color: "#FFFFFF",
                            "&:hover": { backgroundColor: "#3B7E42" },
                          }}
                        >
                          {item.rating}
                        </Button>
                        <Typography sx={{ color: "#878787" }}>
                          {item.ratedes}
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} mt={1}>
                      <Typography variant="h5" mt={1} fontWeight="bold">
                        Available offers :
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} mt={1}>
                      <ReusableListWithDotIcon
                        list={productDetails[0]?.list}
                        title="T&C"
                        icon="icon"
                        maxItemsToShow="6"
                        sx={{
                          color: "#212121",
                          "& .MuiTypography-root": {
                            fontSize: "0.873rem",
                          },
                        }}
                      />
                    </Grid>
                    <Grid
                      item
                      xs={12}
                      sm={12}
                      md={12}
                      mt={1}
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "flex-start",
                      }}
                    >
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={12} md={1}>
                          <Typography variant="h5" mt={1} color="#878787">
                            Description
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={12} md={11}>
                          <Typography
                            variant="h6"
                            mt={1}
                            textAlign="justify"
                            sx={{
                              marginLeft: "10px",
                              color: "#212121",
                              ml: 3,
                              mt: 1,
                            }}
                          >
                            {" "}
                            The weight of the phone is 207 g, and the weight of
                            the screen protector may add an additional 3g. The
                            size and weight of the mobile phone may vary
                            according to configuration, manufacturing process
                            and measurement method. 3. Due to the mobile phone
                            system file occupying space (including Android
                            system and pre-installed apps), the available memory
                            capacity is less than this value. Storage capacity
                            will vary based on software version and may vary
                            from device to device. 4. Photo pixels of different
                            camera modes may vary, please refer to the actual
                            situation. Video pixels of different shooting modes
                            may also vary, please refer to the actual
                          </Typography>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} mt={1}>
                      <Box
                        sx={{
                          border: "1px solid",
                          borderColor: "divider",
                        }}
                      >
                        <Typography variant="h4" mt={1}p={1}>
                          Product Description
                        </Typography>
                        <ProductAvailability />
                      </Box>
                    </Grid>
                  </Grid>
                ))}
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </>
  );
};
export default InnerProductDetails;
