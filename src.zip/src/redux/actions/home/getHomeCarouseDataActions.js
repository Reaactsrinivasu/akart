import * as types from "../actionTypes";
//loading  all users details
export const loadCaroouselDataStart = () => ({
  type: types.LOAD_HOME_CAROUSELDATA_START,
});
export const loadCaroouselDataSuccess = (data) => {
  const action = {
    type: types.LOAD_HOME_CAROUSELDATA_SUCCESS,
    payload: data,
  };
  console.log("data:", data); // Log the action
  return action;
};
export const loadCaroouselDataError = (error) => ({
  type: types.LOAD_HOME_CAROUSELDATA_ERROR,
  payload: error,
});
export default {
  loadCaroouselDataStart,
};



 