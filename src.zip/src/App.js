import React from "react";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Approutes from "./Approutes";
function App() {
  return (
    <>
      <ToastContainer />
      <Approutes />
    </>
  );
}

export default App;

