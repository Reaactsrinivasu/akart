import React from 'react'

const SubNavbarData = () => {
    return (
        <div>SubNavbarData</div>
    );
};

export default SubNavbarData;