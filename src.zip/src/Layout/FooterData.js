import React from 'react'

const FooterData = () => {
    return (
        <div>FooterData</div>
    );
};
export default FooterData;