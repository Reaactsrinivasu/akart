import React from 'react';
import SubNavbar from './SubNavbar';
const SubHeader = () => {
 return (
      <>
        <SubNavbar />
      </>
    );
};

export default SubHeader;