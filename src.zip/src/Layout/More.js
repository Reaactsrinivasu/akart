import React from 'react'
import { Typography } from '@mui/material';
const More = () => {
    return (
      <Typography
        variant="body1"
        sx={{
          color: "blue",
          fontWeight: "bold",
          color: "#ff7e00",
            marginLeft: "20px",
          fontSize:'20px'
        }}
      >
        More
      </Typography>
    );
};
export default More;