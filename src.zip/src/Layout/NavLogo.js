import React from 'react'

const NavLogo = () => {
    return (
        <div>NavLogo</div>
    );
};

export default NavLogo;